import os
os.environ["TF_CPP_MIN_LOG_LEVEL"]= "2"
import tensorflow as tf
import tensorflow_datasets as tfds
import tensorflow_addons as tfa
import math
from tensorflow.keras import layers
from tensorflow import keras

physical_devices = tf.config.list_physical_devices("GPU")
tf.config.experimental.set_memory_growth(physical_devices[0], True)

(dataset_train, dataset_test), dataset_info = tfds.load(
    "mnist",
    split = ["train", "test"],
    shuffle_files = False,
    as_supervised = True,
    with_info = True,
)

@tf.function
def normalize_image(image, label):

    return tf.cast(image, tf.float32) / 255.0, label

@tf.function
def rotate(image, max_degrees=25):
    degrees = tf.random.uniform([], -max_degrees, max_degrees, dtype=tf.float32)
    image = tfa.image.rotate(image, degrees * math.pi /180, interpolation="BILINEAR")
    return image

@tf.function
def augment(image, label):
    #resize
    image = tf.image.resize(image, size=[28,28])
   # image = rotate(image)
    #coloring
    image = tf.image.random_brightness(image, max_delta=0.2)
    image = tf.image.random_contrast(image, lower=0.5, upper=1.5)
    return image, label

AUTOTUNE = tf.data.experimental.AUTOTUNE
BATCH_SIZE = 32

dataset_train = dataset_train.cache()
dataset_train = dataset_train.shuffle(dataset_info.splits["train"].num_examples)
dataset_train = dataset_train.map(normalize_image, num_parallel_calls = AUTOTUNE)
dataset_train = dataset_train.map(augment, num_parallel_calls = AUTOTUNE)
dataset_train = dataset_train.batch(BATCH_SIZE)
dataset_train = dataset_train.prefetch(AUTOTUNE)


dataset_test = dataset_test.map(normalize_image, num_parallel_calls=AUTOTUNE)
dataset_test = dataset_test.batch(BATCH_SIZE)
dataset_test = dataset_test.prefetch(AUTOTUNE)

def my_model():
    #Craeting layers

    # inputs = keras.Input(shape= (28,28,1))

    model = tf.keras.Sequential([
        tf.keras.layers.Flatten(input_shape=(28, 28, 1)),
        tf.keras.layers.Dense(256, activation='relu'),
        tf.keras.layers.Dense(128, activation='relu'),
        tf.keras.layers.Dense(64, activation='relu'),
        tf.keras.layers.Dense(10, activation='softmax')
    ]);


    #Outputs 0123456789

    # outputs = layers.Dense(10, activation="softmax")(x)

    return model

model = my_model()
model.compile(
    loss= keras.losses.SparseCategoricalCrossentropy(from_logits =False),
    optimizer = keras.optimizers.Adam(lr=1e-4),
    metrics = ["accuracy"]
)

model.fit(dataset_train, epochs= 20, verbose= 2)
model.evaluate(dataset_test)
model.save("model")