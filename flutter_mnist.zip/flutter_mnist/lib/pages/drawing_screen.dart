import "package:flutter/material.dart";
import 'package:mnist/deep_learning_model/classifier.dart';

class DrawingScreen extends StatefulWidget {

  @override
  _DrawingScreenState createState() => _DrawingScreenState();
}

class _DrawingScreenState extends State<DrawingScreen> {
  Classifier classifier = Classifier();
  List<Offset> points = [];
  int _number = -1;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          SizedBox(
            height: 50,
          ),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.green, width:2.0),
            ),
            height: 300+2*2.0,
            width: 300+2*2.0,
            child: GestureDetector(
              //inside the container pressing
              onPanUpdate: (DragUpdateDetails details){
                Offset localPosition = details.localPosition;
                setState(() {
                  if(localPosition.dx >= 0 && localPosition.dy <= 300 && localPosition.dy>=0 && localPosition.dy <=300){
                    points.add(localPosition);
                  }

                });
              },

              child: CustomPaint(
                painter: Painter(
                  points: points
                ),
              ),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Text("Number prediction: ", style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
          SizedBox(
            height: 20,
          ),
          Text( _number == -1 ? " " : "$_number", style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                  onPressed: () async {
                    points.add(null);
                    _number = await classifier.classifyingDrawing(points);
                    setState(() {

                    });
              },
                  child: Text("Enter", style: TextStyle(fontSize: 15, color: Colors.black),),

              ),
              TextButton(
                onPressed: (){
                  points.clear();
                  setState(() {
                    _number =-1;
                  });
                },
                child: Text("Restart", style: TextStyle(fontSize: 15, color: Colors.black),),

              ),
            ],

          ),

        ],
      ),
    );
  }
}

class Painter extends CustomPainter{
  final List<Offset> points;
  Painter({this.points});

  final Paint paintDetails = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 4.0
    ..color = Colors.black;

   @override
   void paint(Canvas canvas, Size size){
     for(int i =0; i < points.length -1; i++){
       if(points[i] != null && points[i+1] != null) {
        canvas.drawLine(points[i], points[i + 1], paintDetails);
      }
    }

   }
  @override
  bool shouldRepaint(Painter oldDelegate){
    return true;
  }



}